create database soccer;
use soccer;
select * from player_mast;

-- Q1
SELECT COUNT(DISTINCT team_id) as no_of_countries
FROM player_mast;


-- Q2
select results from match_mast
where results = 'WIN' or 'loss'; 

-- Q3
SELECT play_date as Begin_Date FROM match_mast
WHERE match_no=1;



select * from soccer_venue;
select * from soccer_city;
select * from match_mast; 
-- Q4
SELECT venue_name, city
FROM soccer_venue
JOIN soccer_city
ON soccer_venue.city_id = soccer_city.city_id
JOIN match_mast
ON soccer_venue.venue_id = match_mast.venue_id
WHERE play_stage = 'F';

-- Q5
select * from match_details; 
select * from soccer_country;

SELECT match_no,country_name,goal_score
FROM match_details as md
JOIN soccer_country as sc
ON md.country_id =sc.country_id
WHERE decided_by='N'
ORDER BY match_no;




select * from goal_details; 
select * from soccer_country;
-- Q6
SELECT player_name, count(*) as no_of_goals, country_name
FROM goal_details gd
JOIN player_mast pm ON gd.player_id=pm.player_id
JOIN soccer_country sc ON gd.country_id=sc.country_id
WHERE goal_schedule = 'NT'
GROUP BY player_name,country_name
ORDER BY no_of_goals DESC;



-- Q7
SELECT player_name, country_name, COUNT(*) AS goals
FROM goal_details
JOIN player_mast
ON goal_details.player_id = player_mast.player_id
JOIN soccer_country
ON player_mast.country_id = soccer_country.country_id
GROUP BY player_name, country_name
ORDER BY goals DESC
LIMIT 1;




select * from match_details;
select * from soccer_country;
-- Q8
SELECT match_no,country_name
FROM match_details, soccer_country 
WHERE match_details.country_id=soccer_country.country_id AND a.match_no=1;



-- Q9
SELECT match_no, play_stage, goal_score, audence 
FROM match_mast 
WHERE audence=(SELECT max(audence) FROM match_mast);


-- Q10

SELECT match_no, soccer_country.country_name AS country_name, player_name, COUNT(*) AS goals
FROM goal_details
JOIN soccer_country
ON goal_details.country_id = soccer_country.country_id
JOIN player_mast
ON goal_details.player_id = player_mast.player_id
GROUP BY match_no, soccer_country.country_name, player_name
ORDER BY match_no;

 


